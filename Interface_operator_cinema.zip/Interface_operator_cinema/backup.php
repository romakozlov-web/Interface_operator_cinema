<?php
require_once 'config.php';

$backupDir = __DIR__ . '/backups/';
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0755, true);
}
$filename = $backupDir . 'backup_' . date('Y-m-d_H-i-s') . '.sql';
$command = sprintf(
    'mysqldump --host=%s --port=%s --user=%s --password=%s %s > %s',
    escapeshellarg(DB_HOST),
    escapeshellarg(DB_PORT),
    escapeshellarg(DB_USER),
    escapeshellarg(DB_PASSWORD),
    escapeshellarg(DEFAULT_DB),
    escapeshellarg($filename)
);
system($command, $output);
if ($output === 0) {
    echo "Бэкап успешно создан: $filename\n";
    // Дополнительно: заархивировать и отправить по email
} else {
    echo "Ошибка создания бэкапа\n";
}